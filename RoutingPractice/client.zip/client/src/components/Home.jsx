import React from 'react'

const Home = (props) => {
    return (
    <div>
    Home
    </div>
    )
}

export default Home